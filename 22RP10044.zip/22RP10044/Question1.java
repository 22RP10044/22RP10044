/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question1;
import java.util.Scanner;
/**
 *
 * @author user
 */
class rectangle{
double width;
double length;
public void area(double w,double l){
   width=w;
   length=l;
   System.out.println("THE AREA OF RECTANGLE IS:"+ width*length);
}
public void permeter(double k,double p){
   width=k;
   length=p;
   System.out.println("THE PERIMETER OF RECTANGLE IS:"+ (width+length)/2);
}
}
  
public class question1{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner sc=new Scanner (System.in);
       System.out.println("enter width");
       double a=sc.nextDouble();
       System.out.println("enter length");
       double b=sc.nextDouble();
       rectangle rect=new rectangle();
       rect.area(a, b);
       rect.permeter(a, b);
    }
    
}
