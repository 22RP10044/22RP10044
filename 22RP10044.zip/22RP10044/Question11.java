import java.util.Scanner;

public class question11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a nmbrber: ");
        int nmbr = sc.nextInt();

        // Calculate sum of digits
        int sum = sumofdigit(nmbr);

        // Display the result
        System.out.println("Sum of digits: " + sum);

        sc.close();
    }

    // Static method to calculate sum of digits
    public static int sumofdigit(int nmbr) {
        int sum = 0;
        while (nmbr != 0) {
            int digit = nmbr % 10;
            sum += digit;
            nmbr /= 10;
        }
        return sum;
    }
}
