import java.util.Arrays;

public class question12{
    public static void main(String[] args) {
        int[] arraybubble = {3, 34, 42, 51, 22, 11, 92,0};

        System.out.println(" Array before: " + Arrays.toString(arraybubble));

        bubbleSort(arraybubble);

        System.out.println("Array after: " + Arrays.toString(arraybubble));
    }

    // Static method to perform bubble sort
    public static void bubbleSort(int[] arraybubble) {
        int n = arraybubble.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arraybubble[j] > arraybubble[j + 1]) {
                    // Swap arraybubble[j] and arraybubble[j+1]
                    int temp = arraybubble[j];
                    arraybubble[j] = arraybubble[j + 1];
                    arraybubble[j + 1] = temp;
                }
            }
        }
    }
}
