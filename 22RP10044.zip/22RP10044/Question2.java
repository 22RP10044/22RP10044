/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question2;
import java.util.Scanner;
/**
 *
 * @author user
 */

public class question2 {

 static void sumof(int n1,int n2){
      int sumofnum=0;
      int i;
      for(i=n1;i<=n2;i++)
      {
      sumofnum+=n1;
      }
      System.out.println("SUM OF ALL NUMBERS=:" + sumofnum );

}
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
      System.out.println("input first number:");
      int num1=sc.nextInt();
      System.out.println("input second number:");
      int num2=sc.nextInt();
      sumof(num1,num2);
        
    }
    
}
