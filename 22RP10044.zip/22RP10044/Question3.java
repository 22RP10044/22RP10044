/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question3;
import java.util.Scanner;
/**
 *
 * @author user
 */
class ATM{
double balance=1500;
static String location;
static double maxwithdrawlimit;
ATM(){
location="KARONGI";
maxwithdrawlimit=100000;
  System.out.println(" LOCATION IS:" + location); 
  System.out.println("MAXIMUM WITHDRAW LIMIT:" + maxwithdrawlimit); 
}
//display balance;
public void bal(double b){
balance=b;
    System.out.println("YOUR BALANCE IS:"+balance);
}
//deposit
public void deposit(double depo){
    balance+=depo;
    System.out.println("THE NEW BALANCE IS:" +balance); 
    
}
//withdraw
public void withdraw(double withdrw){
    if((withdrw<=maxwithdrawlimit)&&(withdrw>1000)){
    balance=balance-withdrw;
    System.out.println("THE NEW BALANCE IS:" +balance); 
    }
        else{
             System.out.println("something wrong!");  
        }}
    } 

public class question3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        ATM obj=new ATM();
        obj.balance=1000;
        System.out.println("ENTER AMOUNT WANT TO DEPOSIT:"); 
        double depo=sc.nextDouble();
        obj.deposit(depo);
        System.out.println("ENTER AMOUNT WANT TO WITHDRAW:"); 
        double with=sc.nextDouble();
        obj.withdraw(with);
    }
    
}
