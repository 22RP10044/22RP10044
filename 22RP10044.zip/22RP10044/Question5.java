/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package question5;
import java.util.Scanner;
/**
 *
 * @author user
 */
class recrusiveusive{
    //factorial number using recursion
    static  void calculaterecrusiveusive(int n){
    if(n==1){
    System.out.println("factorial number is:"+n);
    }
    else{
    System.out.println("factorial number is:"+n*(n-1));
    }
        if(n<0){
    System.out.println("sorry,not possible for negative number");
    }
    else if(n==0){
    System.out.println("factorial of 0 is 1");
    }
    else{
    System.out.println("factorial of"+n*(n-1));
    }
    }
}
public class question5 {
    public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     System.out.println("enter number ");
      int nmb=sc.nextInt();
      recrusiveusive obj=new recrusiveusive();
      obj.calculaterecrusiveusive(nmb);
    }
}
