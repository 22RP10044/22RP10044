import java.util.Scanner;

public class question8 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Input Matrix A
        System.out.println("Enter the number of rows and columns of Matrix A:");
        int rowsA = scan.nextInt();
        int colsA = scan.nextInt();
        int[][] matrixA = readMatrix("Matrix A", rowsA, colsA, scan);

        // Input Matrix B
        System.out.println("Enter the number of rows and columns of Matrix B:");
        int rowsB = scan.nextInt();
        int colsB = scan.nextInt();
        int[][] matrixB = readMatrix("Matrix B", rowsB, colsB, scan);

        // Perform multiplication
        int[][] result = multpmatrix(matrixA, matrixB);

        // Display the result
        System.out.println("Result of Matrix Multiplication:");
        displymatrix(result);

        scan.close();
    }

    // Method to read a matrix from user input
    public static int[][] readMatrix(String name, int rows, int cols, Scanner scan) {
        System.out.println("Enter elements of " + name + ":");
        int[][] matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = scan.nextInt();
            }
        }
        return matrix;
    }

    // Method to perform matrix multiplication
    public static int[][] multpmatrix(int[][] matrixA, int[][] matrixB) {
        int rowsA = matrixA.length;
        int colsA = matrixA[0].length;
        int colsB = matrixB[0].length;

        int[][] result = new int[rowsA][colsB];

        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                for (int k = 0; k < colsA; k++) {
                    result[i][j] += matrixA[i][k] * matrixB[k][j];
                }
            }
        }

        return result;
    }

    // Method to print a matrix
    public static void displymatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
